

function [localAEntry] = localAEntry(basis1, basis2, k, i, j)
    
    if i > 3
        
    end
    if j > 3
        
    end

end