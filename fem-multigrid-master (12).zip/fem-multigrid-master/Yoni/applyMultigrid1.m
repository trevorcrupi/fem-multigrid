function multigrid1 = applyMultigrid1(globalA, globalB, height)

    for i = 1:size(p,2)
        Q_j = zeros(size(Z_i), height)   ; %Z_i?????
        A_j = zeros(size(Z_i), size(Z_i));
        
        
    end

end