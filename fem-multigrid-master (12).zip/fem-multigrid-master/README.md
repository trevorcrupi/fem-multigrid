# fem-multigrid
Iterative techniques to solve maxwell's equations on axisymmetric domains. 
